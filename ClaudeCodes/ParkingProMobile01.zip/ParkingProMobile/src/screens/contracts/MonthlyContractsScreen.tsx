import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { contractsApi } from '../../api/contractsApi';
import { MonthlyContractDto } from '../../types/api';
import { colors } from '../../theme/colors';
import { formatDate } from '../../utils/format';

export default function MonthlyContractsScreen() {
  const [contracts, setContracts] = useState<MonthlyContractDto[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await contractsApi.getExpiringSoon(1, 50);
    setContracts(res.items);
  }, []);

  useEffect(() => {
    setIsLoading(true);
    load().finally(() => setIsLoading(false));
  }, [load]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await load();
    setIsRefreshing(false);
  };

  const handleRenew = async (id: string) => {
    setBusyId(id);
    try {
      await contractsApi.renew(id, 1);
      await load();
    } catch {
      Alert.alert('Lỗi', 'Không thể gia hạn hợp đồng.');
    } finally {
      setBusyId(null);
    }
  };

  const handleCancel = async (id: string) => {
    Alert.alert('Huỷ hợp đồng', 'Bạn chắc chắn muốn huỷ hợp đồng này?', [
      { text: 'Không', style: 'cancel' },
      {
        text: 'Huỷ hợp đồng',
        style: 'destructive',
        onPress: async () => {
          setBusyId(id);
          try {
            await contractsApi.cancel(id);
            await load();
          } catch {
            Alert.alert('Lỗi', 'Không thể huỷ hợp đồng.');
          } finally {
            setBusyId(null);
          }
        },
      },
    ]);
  };

  if (isLoading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <FlatList
      style={styles.container}
      contentContainerStyle={{ padding: 16 }}
      data={contracts}
      keyExtractor={item => item.id}
      refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={handleRefresh} />}
      ListHeaderComponent={<Text style={styles.header}>Hợp đồng tháng sắp hết hạn</Text>}
      ListEmptyComponent={<Text style={styles.empty}>Không có hợp đồng nào sắp hết hạn.</Text>}
      renderItem={({ item }) => (
        <View style={styles.card}>
          <Text style={styles.plate}>{item.licensePlate}</Text>
          {item.customerName && <Text style={styles.customer}>{item.customerName}</Text>}
          <Text style={styles.meta}>
            {formatDate(item.startDate)} → {formatDate(item.endDate)}
          </Text>
          <View style={styles.actions}>
            <TouchableOpacity
              style={[styles.actionBtn, styles.renewBtn]}
              disabled={busyId === item.id}
              onPress={() => handleRenew(item.id)}>
              <Text style={styles.renewText}>
                {busyId === item.id ? '...' : 'Gia hạn 1 tháng'}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, styles.cancelBtn]}
              disabled={busyId === item.id}
              onPress={() => handleCancel(item.id)}>
              <Text style={styles.cancelText}>Huỷ</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, backgroundColor: colors.background, justifyContent: 'center' },
  header: { color: colors.textPrimary, fontSize: 18, fontWeight: '700', marginBottom: 12 },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  plate: { color: colors.textPrimary, fontSize: 16, fontWeight: '700' },
  customer: { color: colors.textSecondary, fontSize: 13, marginTop: 2 },
  meta: { color: colors.textMuted, fontSize: 12, marginTop: 6 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  actionBtn: { flex: 1, borderRadius: 8, paddingVertical: 10, alignItems: 'center' },
  renewBtn: { backgroundColor: `${colors.primary}22` },
  renewText: { color: colors.primary, fontWeight: '600', fontSize: 13 },
  cancelBtn: { backgroundColor: `${colors.danger}22` },
  cancelText: { color: colors.danger, fontWeight: '600', fontSize: 13 },
});
