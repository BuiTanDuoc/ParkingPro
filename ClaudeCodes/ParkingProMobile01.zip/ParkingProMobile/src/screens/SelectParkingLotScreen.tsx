import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useAuth } from '../contexts/AuthContext';
import { useParkingLot } from '../contexts/ParkingLotContext';
import { colors } from '../theme/colors';

export default function SelectParkingLotScreen() {
  const { setParkingLot } = useParkingLot();
  const { logout } = useAuth();
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const GUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  const handleSave = async () => {
    if (!GUID_REGEX.test(id.trim())) {
      setError('Id bãi xe không hợp lệ — hãy dán đúng Guid từ Admin Web.');
      return;
    }
    await setParkingLot(id.trim(), name.trim() || 'Bãi xe');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cài đặt bãi xe</Text>
      <Text style={styles.hint}>
        Mở Admin Web → trang Dashboard, copy Id của bãi xe bạn phụ trách và dán vào đây.
        Chỉ cần làm 1 lần trên thiết bị này.
      </Text>

      <Text style={styles.label}>Id bãi xe (Guid)</Text>
      <TextInput
        style={styles.input}
        placeholder="vd: 3fa85f64-5717-4562-b3fc-2c963f66afa6"
        placeholderTextColor={colors.textMuted}
        autoCapitalize="none"
        value={id}
        onChangeText={setId}
      />

      <Text style={styles.label}>Tên hiển thị (không bắt buộc)</Text>
      <TextInput
        style={styles.input}
        placeholder="Bãi xe Trung Tâm Quận 1"
        placeholderTextColor={colors.textMuted}
        value={name}
        onChangeText={setName}
      />

      {error && <Text style={styles.error}>{error}</Text>}

      <TouchableOpacity style={styles.button} onPress={handleSave}>
        <Text style={styles.buttonText}>Lưu và tiếp tục</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.logoutLink} onPress={logout}>
        <Text style={styles.logoutText}>Đăng xuất</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 24, justifyContent: 'center' },
  title: { fontSize: 22, fontWeight: '700', color: colors.textPrimary, marginBottom: 8 },
  hint: { color: colors.textSecondary, fontSize: 13, lineHeight: 19, marginBottom: 24 },
  label: { color: colors.textSecondary, fontSize: 13, marginBottom: 6 },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: colors.textPrimary,
    fontSize: 15,
    marginBottom: 16,
  },
  error: { color: colors.danger, fontSize: 13, marginBottom: 12 },
  button: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonText: { color: colors.white, fontSize: 16, fontWeight: '600' },
  logoutLink: { alignItems: 'center', marginTop: 20 },
  logoutText: { color: colors.textMuted, fontSize: 13 },
});
