import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { slotsApi } from '../../api/slotsApi';
import { SlotStatusDto } from '../../types/api';
import { colors, slotStatusColor, slotStatusLabel } from '../../theme/colors';
import { useParkingLot } from '../../contexts/ParkingLotContext';
import { useParkingHub } from '../../hooks/useParkingHub';
import SlotChip from '../../components/SlotChip';
import SlotDetailModal from '../../components/SlotDetailModal';
import { RootStackParamList } from '../../navigation/types';

const LEGEND_ORDER: SlotStatusDto['status'][] = ['Trong', 'DangDauXe', 'DaDatTruoc', 'BaoTri'];

export default function ParkingMapScreen() {
  const { parkingLotId, parkingLotName } = useParkingLot();
  // CheckOut là màn hình ở root stack, không phải trong tab — dùng getParent() để điều hướng.
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

  const [slots, setSlots] = useState<SlotStatusDto[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<SlotStatusDto | null>(null);

  const loadSlots = useCallback(async () => {
    if (!parkingLotId) return;
    const data = await slotsApi.getStatus(parkingLotId);
    setSlots(data);
  }, [parkingLotId]);

  useEffect(() => {
    setIsLoading(true);
    loadSlots().finally(() => setIsLoading(false));
  }, [loadSlots]);

  const { connectionState } = useParkingHub({
    parkingLotId,
    onSlotStatusChanged: evt => {
      setSlots(prev =>
        prev.map(s => (s.slotId === evt.slotId ? { ...s, status: evt.newStatus } : s)),
      );
    },
    // Check-in/out cũng làm đổi trạng thái slot — refetch để lấy chính xác biển số/slot mới gán
    onSessionCheckedIn: () => loadSlots(),
    onSessionCheckedOut: () => loadSlots(),
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadSlots();
    setIsRefreshing(false);
  };

  const grouped = useMemo(() => {
    const map = new Map<string, SlotStatusDto[]>();
    for (const slot of slots) {
      const key = slot.zoneName;
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(slot);
    }
    return Array.from(map.entries());
  }, [slots]);

  const summary = useMemo(() => {
    const total = slots.length;
    const free = slots.filter(s => s.status === 'Trong').length;
    return { total, free };
  }, [slots]);

  if (!parkingLotId) return null;

  if (isLoading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.lotName}>{parkingLotName}</Text>
          <Text style={styles.summary}>
            {summary.free}/{summary.total} chỗ trống
          </Text>
        </View>
        <View style={styles.connectionRow}>
          <View
            style={[
              styles.connectionDot,
              {
                backgroundColor:
                  connectionState === 'connected' ? colors.accent : colors.warning,
              },
            ]}
          />
          <Text style={styles.connectionText}>
            {connectionState === 'connected'
              ? 'Realtime'
              : connectionState === 'connecting'
              ? 'Đang kết nối...'
              : connectionState === 'reconnecting'
              ? 'Đang kết nối lại...'
              : 'Mất kết nối'}
          </Text>
        </View>
      </View>

      <View style={styles.legend}>
        {LEGEND_ORDER.map(status => (
          <View key={status} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: slotStatusColor[status] }]} />
            <Text style={styles.legendText}>{slotStatusLabel[status]}</Text>
          </View>
        ))}
      </View>

      <ScrollView
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={handleRefresh} />}>
        {grouped.map(([zoneName, zoneSlots]) => (
          <View key={zoneName} style={styles.zoneSection}>
            <Text style={styles.zoneTitle}>{zoneName}</Text>
            <View style={styles.slotGrid}>
              {zoneSlots.map(slot => (
                <SlotChip key={slot.slotId} slot={slot} onPress={setSelectedSlot} />
              ))}
            </View>
          </View>
        ))}
        <View style={{ height: 24 }} />
      </ScrollView>

      <SlotDetailModal
        slot={selectedSlot}
        visible={!!selectedSlot}
        onClose={() => setSelectedSlot(null)}
        onSlotUpdated={loadSlots}
        onCheckOut={(sessionId, licensePlate, slotCode) =>
          navigation.navigate('CheckOut', { sessionId, licensePlate, slotCode })
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, backgroundColor: colors.background, justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
  },
  lotName: { color: colors.textPrimary, fontSize: 18, fontWeight: '700' },
  summary: { color: colors.textSecondary, fontSize: 13, marginTop: 2 },
  connectionRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  connectionDot: { width: 8, height: 8, borderRadius: 4 },
  connectionText: { color: colors.textSecondary, fontSize: 12 },
  legend: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    paddingBottom: 12,
    gap: 14,
  },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { color: colors.textMuted, fontSize: 11 },
  zoneSection: { paddingHorizontal: 16, marginTop: 12 },
  zoneTitle: { color: colors.textPrimary, fontSize: 14, fontWeight: '600', marginBottom: 4 },
  slotGrid: { flexDirection: 'row', flexWrap: 'wrap' },
});
