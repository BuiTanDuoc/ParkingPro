import React from 'react';
import { StyleSheet, Text, TouchableOpacity } from 'react-native';
import { SlotStatusDto } from '../types/api';
import { colors, slotStatusColor } from '../theme/colors';

interface Props {
  slot: SlotStatusDto;
  onPress: (slot: SlotStatusDto) => void;
}

export default function SlotChip({ slot, onPress }: Props) {
  const color = slotStatusColor[slot.status] ?? colors.disabled;

  return (
    <TouchableOpacity
      style={[styles.chip, { borderColor: color, backgroundColor: `${color}22` }]}
      onPress={() => onPress(slot)}
      activeOpacity={0.7}>
      <Text style={[styles.code, { color }]}>{slot.code}</Text>
      {slot.type === 'Vip' && <Text style={styles.badge}>VIP</Text>}
      {slot.type === 'DanhChoVeThang' && <Text style={styles.badge}>Tháng</Text>}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  chip: {
    width: 72,
    height: 60,
    borderRadius: 10,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 5,
  },
  code: { fontSize: 14, fontWeight: '700' },
  badge: {
    fontSize: 9,
    color: colors.textSecondary,
    marginTop: 2,
  },
});
