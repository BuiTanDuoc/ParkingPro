import { apiClient } from './client';
import { MonthlyContractDto, PagedResult } from '../types/api';

export const contractsApi = {
  getExpiringSoon: (pageNumber = 1, pageSize = 20) =>
    apiClient
      .get<PagedResult<MonthlyContractDto>>('/monthly-contracts/expiring-soon', {
        params: { pageNumber, pageSize },
      })
      .then(r => r.data),

  getBySlot: (slotId: string) =>
    apiClient.get<MonthlyContractDto>(`/monthly-contracts/by-slot/${slotId}`).then(r => r.data),

  renew: (id: string, additionalMonths: number) =>
    apiClient
      .post<MonthlyContractDto>(`/monthly-contracts/${id}/renew`, null, {
        params: { additionalMonths },
      })
      .then(r => r.data),

  cancel: (id: string) => apiClient.post(`/monthly-contracts/${id}/cancel`).then(r => r.data),
};
