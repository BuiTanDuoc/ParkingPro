import { apiClient } from './client';
import { LoginRequest, LoginResponse } from '../types/api';

export const authApi = {
  login: (payload: LoginRequest) =>
    apiClient.post<LoginResponse>('/auth/login', payload).then(r => r.data),

  revokeToken: (refreshToken: string) =>
    apiClient.post('/auth/revoke-token', { refreshToken }).then(r => r.data),
};
