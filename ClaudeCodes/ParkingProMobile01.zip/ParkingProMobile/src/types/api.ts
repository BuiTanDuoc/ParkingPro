// Các type này map 1-1 với DTO của ParkingPro.API để tránh lệch field.

export type UserRole = 'Admin' | 'Manager' | 'Staff' | 'Customer';

export type SlotStatus = 'Trong' | 'DangDauXe' | 'DaDatTruoc' | 'BaoTri';
export type SlotType = 'Thuong' | 'Vip' | 'DanhChoVeThang';
export type VehicleType = 'XeMay' | 'OToDuoi7Cho' | 'OToTren7Cho' | 'XeTai';
export type SessionType = 'TheoGio' | 'TheoNgay' | 'TheoThang';
export type SessionStatus = 'DangGuiXe' | 'DaThanhToan' | 'DaHuy';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  userId: string;
  fullName: string;
  role: UserRole;
  accessToken: string;
  refreshToken: string;
  accessTokenExpiresAtUtc: string;
}

export interface RefreshTokenRequest {
  refreshToken: string;
}

export interface UserProfileDto {
  id: string;
  fullName: string;
  email: string;
  phoneNumber?: string | null;
  role: UserRole;
  avatarUrl: string;
  isActive: boolean;
}

export interface SlotStatusDto {
  slotId: string;
  zoneId: string;
  code: string;
  zoneName: string;
  status: SlotStatus;
  type: SlotType;
  description?: string | null;
  currentLicensePlate?: string | null;
}

export interface ZoneDto {
  id: string;
  parkingLotId: string;
  name: string;
}

export interface ParkingSessionDto {
  id: string;
  licensePlate: string;
  slotCode: string;
  sessionType: SessionType;
  status: SessionStatus;
  checkInAtUtc: string;
  checkOutAtUtc?: string | null;
  totalAmount?: number | null;
  checkInImageUrl?: string | null;
  checkOutImageUrl?: string | null;
}

export interface CheckInResponse {
  sessionId: string;
  licensePlate: string;
  slotCode: string;
  checkInAtUtc: string;
  sessionType: SessionType;
  checkInImageUrl: string;
}

export interface CheckOutResponse {
  sessionId: string;
  licensePlate: string;
  checkInAtUtc: string;
  checkOutAtUtc: string;
  totalAmount: number;
  slotCode: string;
  checkOutImageUrl: string;
}

export interface MonthlyContractDto {
  id: string;
  slotId: string;
  slotCode?: string;
  licensePlate: string;
  customerName?: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

export interface RevenueReportDto {
  date: string;
  totalAmount: number;
  sessionCount: number;
}

export interface OccupancyReportDto {
  parkingLotId: string;
  totalSlots: number;
  occupiedSlots: number;
  occupancyRate: number;
}

export interface PagedResult<T> {
  items: T[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
}

export interface ParkingLotSummary {
  id: string;
  name: string;
}

// Sự kiện realtime từ ParkingHub ("/hubs/parking")
export interface SlotStatusChangedEvent {
  slotId: string;
  newStatus: SlotStatus;
}
export interface SessionCheckedInEvent {
  sessionId: string;
}
export interface SessionCheckedOutEvent {
  sessionId: string;
}
